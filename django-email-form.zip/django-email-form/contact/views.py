from django.shortcuts import render, redirect
from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse
from django.conf import settings
from .forms import ContactForm

def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            message = form.cleaned_data['message']
            
            subject = f"Contact Form Message from {name}"
            email_message = f"New message from: {name}\nEmail: {email}\n\nMessage:\n{message}"
            
            try:
                send_mail(
                    subject,
                    email_message,
                    settings.EMAIL_HOST_USER,
                    [settings.EMAIL_HOST_USER], # Sending the mail to yourself
                    fail_silently=False,
                )
                return redirect('contact_success')
            except BadHeaderError:
                return HttpResponse('Invalid header found.')
            except Exception as e:
                return HttpResponse(f'An error occurred: {e}')
    else:
        form = ContactForm()
    return render(request, 'contact/contact_form.html', {'form': form})

def contact_success(request):
    return render(request, 'contact/success.html')